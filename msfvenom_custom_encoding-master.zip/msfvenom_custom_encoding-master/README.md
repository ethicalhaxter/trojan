# Metasploit Venom (Almost) FUD Executable Generator
A rewritten version of the (Almost) Fully Undetectable EXE I originally made.
YOU MUST HAVE MinGW INSTALLED LIKE THE PROCEDURE I'VE SHOWN IN NULL-BYTE
http://null-byte.wonderhowto.com/forum/set-up-mingw-kali-using-wine-0159622/


This is a reworked version. Originally, you just pasted in the code. I've turned it into a simple bash script.
