
class constant():
	folder_name = 'results'
	MAX_HELP_POSITION = 27
	CURRENT_VERSION = '1.0'
	output = None 
	file_logger = None 

	# jitsi options
	jitsi_masterpass = None

	# mozilla options
	manually = None
	path = None
	bruteforce = None
	specific_path = None
	mozilla_software = ''
	
	# ie options
	ie_historic = None
	
	# total password found
	nbPasswordFound = 0
	passwordFound = []
