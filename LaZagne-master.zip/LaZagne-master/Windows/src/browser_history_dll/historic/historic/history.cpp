// historic.cpp�: d�finit les fonctions export�es pour l'application DLL.
//

#include "stdafx.h"


