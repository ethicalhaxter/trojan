
class bcolors():
	HEADER = '\033[95m'
	OKBLUE = '\033[94m'
	OK = '\033[92m'
	WARNING = '\033[96m'
	FAIL = '\033[91m'
	TITLE = '\033[93m'
	ENDC = '\033[0m'
	
